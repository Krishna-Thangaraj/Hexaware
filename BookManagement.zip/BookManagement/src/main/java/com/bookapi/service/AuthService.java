package com.bookapi.service;

import com.bookapi.dto.AuthRequest;
import com.bookapi.model.User;
import com.bookapi.payload.LoginRequest;
import com.bookapi.payload.LoginResponse;

public interface AuthService {
    LoginResponse login(LoginRequest request);         // For login (email + password)
    User register(AuthRequest request);
    String authenticate(AuthRequest request);          // Optional: direct token response
}
