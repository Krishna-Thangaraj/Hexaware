package com.bookapi;

import com.bookapi.controller.BookController;
import com.bookapi.model.Book;
import com.bookapi.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookControllerTest {

    @Mock
    private BookService bookService;

    @InjectMocks
    private BookController bookController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllBooks() {
        // Arrange
        Book book = new Book(1L, "Book Title", "Author", "1234567890", 2024);
        when(bookService.getAllBooks()).thenReturn(List.of(book));

        // Act
        ResponseEntity<?> response = bookController.getAllBooks();

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertTrue(response.getBody().toString().contains("Book Title"));
        verify(bookService, times(1)).getAllBooks();
    }
}
