package com.hexaware.dao;

import com.hexaware.entity.*;
import com.hexaware.util.DBConnUtil;
import com.hexaware.exception.ArtWorkNotFoundException;
import com.hexaware.exception.UserNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VirtualArtGalleryImpl implements IVirtualArtGallery {
    private Connection conn;

    public VirtualArtGalleryImpl() {
    	this.conn = DBConnUtil.getDBConn();
    }

    @Override
    public boolean addArtwork(Artwork artwork) {
        String sql = "INSERT INTO artwork (artworkId, title, description, creationDate, medium, imageUrl) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, artwork.getArtworkId());
            stmt.setString(2, artwork.getTitle());
            stmt.setString(3, artwork.getDescription());
            stmt.setString(4, artwork.getCreationDate());
            stmt.setString(5, artwork.getMedium());
            stmt.setString(6, artwork.getImageUrl());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateArtwork(Artwork artwork) {
        String sql = "UPDATE artwork SET title=?, description=?, creationDate=?, medium=?, imageUrl=? WHERE artworkId=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, artwork.getTitle());
            stmt.setString(2, artwork.getDescription());
            stmt.setString(3, artwork.getCreationDate());
            stmt.setString(4, artwork.getMedium());
            stmt.setString(5, artwork.getImageUrl());
            stmt.setInt(6, artwork.getArtworkId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean removeArtwork(int artworkId) {
        String sql = "DELETE FROM artwork WHERE artworkId=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, artworkId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Artwork getArtworkById(int artworkId) {
        String sql = "SELECT * FROM artwork WHERE artworkId=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, artworkId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Artwork(rs.getInt("artworkId"), rs.getString("title"),
                        rs.getString("description"), rs.getString("creationDate"),
                        rs.getString("medium"), rs.getString("imageUrl"));
            } else {
                throw new ArtWorkNotFoundException("Artwork not found with ID: " + artworkId);
            }
        } catch (SQLException | ArtWorkNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Artwork> searchArtworks(String keyword) {
        List<Artwork> list = new ArrayList<>();
        String sql = "SELECT * FROM artwork WHERE title LIKE ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + keyword + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new Artwork(rs.getInt("artworkId"), rs.getString("title"),
                        rs.getString("description"), rs.getString("creationDate"),
                        rs.getString("medium"), rs.getString("imageUrl")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean addArtworkToFavorite(int userId, int artworkId) {
        String sql = "INSERT INTO user_favorite_artwork (userId, artworkId) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, artworkId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean removeArtworkFromFavorite(int userId, int artworkId) {
        String sql = "DELETE FROM user_favorite_artwork WHERE userId=? AND artworkId=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, artworkId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Artwork> getUserFavoriteArtworks(int userId) {
        List<Artwork> favs = new ArrayList<>();
        String sql = "SELECT a.* FROM artwork a JOIN user_favorite_artwork ufa ON a.artworkId = ufa.artworkId WHERE ufa.userId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                favs.add(new Artwork(rs.getInt("artworkId"), rs.getString("title"),
                        rs.getString("description"), rs.getString("creationDate"),
                        rs.getString("medium"), rs.getString("imageUrl")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return favs;
    }

 @Override
 public boolean addGallery(Gallery g) {
     String sql = "INSERT INTO Gallery (galleryId, name, description, location, curator, openingHours) VALUES (?, ?, ?, ?, ?, ?)";
     try (PreparedStatement stmt = conn.prepareStatement(sql)) {
         stmt.setInt(1, g.getGalleryId());
         stmt.setString(2, g.getName());
         stmt.setString(3, g.getDescription());
         stmt.setString(4, g.getLocation());
         stmt.setInt(5, g.getCurator());
         stmt.setString(6, g.getOpeningHours());
         return stmt.executeUpdate() > 0;
     } catch (SQLException e) {
         e.printStackTrace();
         return false;
     }
 }

 @Override
 public boolean updateGallery(Gallery g) {
     String sql = "UPDATE Gallery SET name=?, description=?, location=?, curator=?, openingHours=? WHERE galleryId=?";
     try (PreparedStatement stmt = conn.prepareStatement(sql)) {
         stmt.setString(1, g.getName());
         stmt.setString(2, g.getDescription());
         stmt.setString(3, g.getLocation());
         stmt.setInt(4, g.getCurator());
         stmt.setString(5, g.getOpeningHours());
         stmt.setInt(6, g.getGalleryId());
         return stmt.executeUpdate() > 0;
     } catch (SQLException e) {
         e.printStackTrace();
         return false;
     }
 }

 @Override
 public boolean removeGallery(int galleryId) {
     String sql = "DELETE FROM Gallery WHERE galleryId=?";
     try (PreparedStatement stmt = conn.prepareStatement(sql)) {
         stmt.setInt(1, galleryId);
         return stmt.executeUpdate() > 0;
     } catch (SQLException e) {
         e.printStackTrace();
         return false;
     }
 }

 @Override
 public List<Gallery> searchGallery(String keyword) {
     List<Gallery> galleries = new ArrayList<>();
     String sql = "SELECT * FROM Gallery WHERE name LIKE ?";
     try (PreparedStatement stmt = conn.prepareStatement(sql)) {
         stmt.setString(1, "%" + keyword + "%");
         ResultSet rs = stmt.executeQuery();
         while (rs.next()) {
             Gallery g = new Gallery(
                 rs.getInt("galleryId"),
                 rs.getString("name"),
                 rs.getString("description"),
                 rs.getString("location"),
                 rs.getInt("curator"),
                 rs.getString("openingHours")
             );
             galleries.add(g);
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
     return galleries;
 }

}
