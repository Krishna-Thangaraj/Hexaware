package com.hexaware.entity;

public class Artwork {
    private int artworkId;
    private String title;
    private String description;
    private String creationDate;
    private String medium;
    private String imageUrl;

    public Artwork() {}

    public Artwork(int artworkId, String title, String description, String creationDate, String medium, String imageUrl) {
        this.artworkId = artworkId;
        this.title = title;
        this.description = description;
        this.creationDate = creationDate;
        this.medium = medium;
        this.imageUrl = imageUrl;
    }

	public int getArtworkId() {
		return artworkId;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public String getMedium() {
		return medium;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setArtworkId(int artworkId) {
		this.artworkId = artworkId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public void setMedium(String medium) {
		this.medium = medium;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Artwork [artworkId=" + artworkId + ", title=" + title + ", description=" + description
				+ ", creationDate=" + creationDate + ", medium=" + medium + ", imageUrl=" + imageUrl + "]";
	}
}
