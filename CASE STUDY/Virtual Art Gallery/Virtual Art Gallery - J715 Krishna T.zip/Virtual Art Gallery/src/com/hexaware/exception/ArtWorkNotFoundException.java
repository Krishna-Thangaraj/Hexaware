package com.hexaware.exception;

public class ArtWorkNotFoundException extends Exception {
    public ArtWorkNotFoundException(String msg) {
        super(msg);
    }

	public ArtWorkNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ArtWorkNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ArtWorkNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ArtWorkNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "ArtWorkNotFoundException";
	}
}
