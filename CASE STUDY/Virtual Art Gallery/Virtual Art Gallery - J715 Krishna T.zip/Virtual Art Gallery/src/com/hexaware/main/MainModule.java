package com.hexaware.main;

import com.hexaware.dao.VirtualArtGalleryImpl;
import com.hexaware.entity.Artwork;
import com.hexaware.entity.Gallery;
import com.hexaware.exception.ArtWorkNotFoundException;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();
        Scanner sc = new Scanner(System.in);
        int ch;

        do {
            System.out.println("\nVirtual Art Gallery");
            System.out.println("1. Add Artwork");
            System.out.println("2. Update Artwork");
            System.out.println("3. Delete Artwork");
            System.out.println("4. View Artwork");
            System.out.println("5. Search Artwork");
            System.out.println("6. Add to Favorite");
            System.out.println("7. View Favorites");
            System.out.println("8. Add Gallery");
            System.out.println("9. Update Gallery");
            System.out.println("10. Search Gallery");
            System.out.println("11. Delete Gallery");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            ch = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (ch) {
                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Title: ");
                    String title = sc.nextLine();
                    System.out.print("Desc: ");
                    String desc = sc.nextLine();
                    System.out.print("Date: ");
                    String date = sc.nextLine();
                    System.out.print("Medium: ");
                    String medium = sc.nextLine();
                    System.out.print("Image URL: ");
                    String url = sc.nextLine();
                    gallery.addArtwork(new Artwork(id, title, desc, date, medium, url));
                    break;

                case 2:
                    System.out.print("ID: ");
                    id = sc.nextInt(); sc.nextLine();
                    System.out.print("Updated Title: ");
                    title = sc.nextLine();
                    System.out.print("Updated Desc: ");
                    desc = sc.nextLine();
                    System.out.print("Updated Date: ");
                    date = sc.nextLine();
                    System.out.print("Updated Medium: ");
                    medium = sc.nextLine();
                    System.out.print("Updated Image URL: ");
                    url = sc.nextLine();
                    gallery.updateArtwork(new Artwork(id, title, desc, date, medium, url));
                    break;

                case 3:
                    System.out.print("Enter Artwork ID to delete: ");
                    id = sc.nextInt();
                    gallery.removeArtwork(id);
                    break;

                case 4:
                    System.out.print("Enter Artwork ID: ");
				System.out.println(gallery.getArtworkById(sc.nextInt()));
                    break;

                case 5:
                    System.out.print("Enter keyword to search artworks: ");
                    String keyword = sc.nextLine();
                    List<Artwork> results = gallery.searchArtworks(keyword);
                    if (results.isEmpty()) {
                        System.out.println("No artworks found.");
                    } else {
                        results.forEach(System.out::println);
                    }
                    break;

                case 6:
                    System.out.print("Enter User ID: ");
                    int userId = sc.nextInt();
                    System.out.print("Enter Artwork ID to add to favorites: ");
                    int artId = sc.nextInt();
                    gallery.addArtworkToFavorite(userId, artId);
                    break;

                case 7:
                    System.out.print("Enter User ID: ");
                    userId = sc.nextInt();
                    List<Artwork> favorites = gallery.getUserFavoriteArtworks(userId);
                    if (favorites.isEmpty()) {
                        System.out.println("No favorite artworks found.");
                    } else {
                        favorites.forEach(System.out::println);
                    }
                    break;

                case 8:
                    System.out.print("Enter Gallery ID: ");
                    int gid = sc.nextInt(); sc.nextLine();
                    System.out.print("Name: ");
                    String gname = sc.nextLine();
                    System.out.print("Description: ");
                    String gdesc = sc.nextLine();
                    System.out.print("Location: ");
                    String gloc = sc.nextLine();
                    System.out.print("Curator (Artist ID): ");
                    int curator = sc.nextInt(); sc.nextLine();
                    System.out.print("Opening Hours: ");
                    String hours = sc.nextLine();
                    Gallery g = new Gallery(gid, gname, gdesc, gloc, curator, hours);
                    gallery.addGallery(g);
                    break;

                case 9:
                    System.out.print("Enter Gallery ID to update: ");
                    gid = sc.nextInt(); sc.nextLine();
                    System.out.print("Updated Name: ");
                    gname = sc.nextLine();
                    System.out.print("Updated Description: ");
                    gdesc = sc.nextLine();
                    System.out.print("Updated Location: ");
                    gloc = sc.nextLine();
                    System.out.print("Updated Curator (Artist ID): ");
                    curator = sc.nextInt(); sc.nextLine();
                    System.out.print("Updated Opening Hours: ");
                    hours = sc.nextLine();
                    g = new Gallery(gid, gname, gdesc, gloc, curator, hours);
                    gallery.updateGallery(g);
                    break;

                case 10:
                    System.out.print("Enter gallery keyword to search: ");
                    String searchKey = sc.nextLine();
                    List<Gallery> galleryList = gallery.searchGallery(searchKey);
                    if (galleryList.isEmpty()) {
                        System.out.println("No galleries found.");
                    } else {
                        for (Gallery gal : galleryList) {
                            System.out.println(gal);
                        }
                    }
                    break;

                case 11:
                    System.out.print("Enter gallery ID to delete: ");
                    gid = sc.nextInt();
                    gallery.removeGallery(gid);
                    break;

                case 0:
                    System.out.println("Thank you for visiting the Virtual Art Gallery!");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }

        } while (ch != 0);

        sc.close();
    }
}
