package com.hexaware.test;

import com.hexaware.dao.VirtualArtGalleryImpl;
import com.hexaware.entity.Artwork;
import com.hexaware.entity.Gallery;
import org.junit.*;

import java.util.List;

public class VirtualArtGalleryTest {

    private static VirtualArtGalleryImpl galleryService;

    @BeforeClass
    public static void setup() {
        galleryService = new VirtualArtGalleryImpl();
    }

    @Test
    public void testAddArtwork() {
        Artwork artwork = new Artwork(201, "Sunset", "A sunset over the mountains", "2024-04-01", "Oil", "sunset.jpg");
        Assert.assertTrue(galleryService.addArtwork(artwork));
    }

    @Test
    public void testUpdateArtwork() {
        Artwork artwork = new Artwork(201, "Sunset Glow", "Updated desc", "2024-04-01", "Oil on Canvas", "sunset_updated.jpg");
        Assert.assertTrue(galleryService.updateArtwork(artwork));
    }

    @Test
    public void testSearchArtworks() {
        List<Artwork> list = galleryService.searchArtworks("Sunset");
        Assert.assertFalse("Artwork search should not return empty", list.isEmpty());
    }

    @Test
    public void testRemoveArtwork() {
        Assert.assertTrue(galleryService.removeArtwork(201));
    }

    // 🖼️ Gallery Management

    @Test
    public void testAddGallery() {
        Gallery g = new Gallery(301, "Modern Art House", "Gallery for modern artworks", "New York", 101, "10AM - 6PM");
        Assert.assertTrue(galleryService.addGallery(g));
    }

    @Test
    public void testUpdateGallery() {
        Gallery g = new Gallery(301, "Modern Art House Revamped", "Revamped description", "New York", 101, "9AM - 7PM");
        Assert.assertTrue(galleryService.updateGallery(g));
    }

    @Test
    public void testSearchGallery() {
        List<Gallery> results = galleryService.searchGallery("Modern");
        Assert.assertFalse("Gallery search should not return empty", results.isEmpty());
    }

    @Test
    public void testRemoveGallery() {
        Assert.assertTrue(galleryService.removeGallery(301));
    }
}
