package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.InputStream;

public class DBConnUtil {

    private static String url;
    private static String username;
    private static String password;
    private static String driver;

    static {
        try {
            Properties props = new Properties();

            // Load db.properties file from classpath
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            InputStream in = loader.getResourceAsStream("db.properties");

            if (in == null) {
                throw new RuntimeException("db.properties file not found in classpath!");
            }

            props.load(in);

            driver = props.getProperty("driver");
            url = props.getProperty("url");
            username = props.getProperty("username");
            password = props.getProperty("password");

            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            System.out.println("Unable to load DB properties: " + e.getMessage());
        }
    }

    public static Connection getDBConn() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/VirtualArtGallery","root", "Welcome@11!");
        } catch (Exception e) {
            System.out.println("Unable to establish DB connection: " + e.getMessage());
            return null;
        }
    }
}
