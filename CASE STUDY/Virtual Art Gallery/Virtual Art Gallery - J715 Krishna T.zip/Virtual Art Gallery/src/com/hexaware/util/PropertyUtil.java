package com.hexaware.util;

import java.io.InputStream;
import java.util.Properties;

public class PropertyUtil {
    public static Properties loadProperties(String fileName) {
        Properties props = new Properties();

        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            InputStream in = loader.getResourceAsStream(fileName);

            if (in == null) {
                throw new RuntimeException(fileName + " file not found in classpath!");
            }

            props.load(in);
        } catch (Exception e) {
            System.out.println("Unable to load properties from file: " + e.getMessage());
        }

        return props;
    }
}
