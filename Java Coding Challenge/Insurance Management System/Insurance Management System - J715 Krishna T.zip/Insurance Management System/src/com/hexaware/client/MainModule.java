package com.hexaware.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Scanner;

import com.hexaware.dao.IPolicyService;
import com.hexaware.dao.InsuranceServiceImpl;
import com.hexaware.entity.Policy;
import com.hexaware.exception.DatabaseException;
import com.hexaware.exception.PolicyNotFoundException;
import com.hexaware.util.HexaConstants;

public class MainModule {

    private static Scanner scanner = new Scanner(System.in);
    private static IPolicyService service = new InsuranceServiceImpl();

    public static void main(String[] args) {
        String option;
        do {
            try {
                showMenu();
                System.out.print(HexaConstants.CONTINUE_PROMPT);
                option = scanner.next();
            } catch (Exception e) {
                System.out.println(HexaConstants.INVALID_INPUT + e.getMessage());
                scanner.nextLine(); // clear buffer
                option = "y";
            }
        } while (option.equalsIgnoreCase("y"));
    }

    public static void showMenu() {
        System.out.println(HexaConstants.MENU);
        System.out.print(HexaConstants.ENTER_CHOICE);
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
        case 1:
            createPolicy();
            break;
        case 2:
            getPolicyById();
            break;
        case 3:
            viewAllPolicies();
            break;
        case 4:
            updatePolicy();
            break;
        case 5:
            deletePolicy();
            break;
        default:
            System.out.println(HexaConstants.INVALID_CHOICE);
    }
    }

    public static void createPolicy() {
        try {
            System.out.print(HexaConstants.ENTER_POLICY_NAME);
            String name = scanner.nextLine();

            System.out.print(HexaConstants.ENTER_COVERAGE_AMOUNT);
            double coverage = scanner.nextDouble();
            scanner.nextLine();

            System.out.print(HexaConstants.ENTER_START_DATE);
            String startInput = scanner.nextLine();
            LocalDate startDate = LocalDate.parse(startInput, DateTimeFormatter.ofPattern(HexaConstants.DATE_FORMAT));

            System.out.print(HexaConstants.ENTER_END_DATE);
            String endInput = scanner.nextLine();
            LocalDate endDate = LocalDate.parse(endInput, DateTimeFormatter.ofPattern(HexaConstants.DATE_FORMAT));

            Policy policy = new Policy(0, name, coverage, startDate, endDate);
            boolean status = service.createPolicy(policy);
            System.out.println(status ? HexaConstants.POLICY_CREATED : HexaConstants.POLICY_CREATION_FAILED);
        } catch (Exception e) {
            System.out.println(HexaConstants.INVALID_INPUT + e.getMessage());
            scanner.nextLine(); // flush
        }
    }


    private static void getPolicyById() {
        try {
            System.out.print(HexaConstants.ENTER_POLICY_ID);
            int id = scanner.nextInt();
            Policy policy = service.getPolicy(id);
            displayPolicy(policy);
        } catch (PolicyNotFoundException | DatabaseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(HexaConstants.INVALID_INPUT + e.getMessage());
            scanner.nextLine();
        }
    }

    private static void viewAllPolicies() {
        try {
            Collection<Policy> policies = service.getAllPolicies();
            if (policies.isEmpty()) {
                System.out.println(HexaConstants.NO_POLICIES_FOUND);
            } else {
                policies.forEach(MainModule::displayPolicy);
            }
        } catch (DatabaseException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void updatePolicy() {
        try {
            System.out.print(HexaConstants.ENTER_POLICY_ID_UPDATE);
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print(HexaConstants.ENTER_POLICY_NAME);
            String name = scanner.nextLine();

            System.out.print(HexaConstants.ENTER_COVERAGE_AMOUNT);
            double coverage = scanner.nextDouble();
            scanner.nextLine();

            

            System.out.print(HexaConstants.ENTER_START_DATE);
            LocalDate startDate = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ofPattern(HexaConstants.DATE_FORMAT));
            scanner.nextLine();

            System.out.print(HexaConstants.ENTER_END_DATE);
            LocalDate endDate = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ofPattern(HexaConstants.DATE_FORMAT));

            Policy policy = new Policy(id, name, coverage, startDate, endDate);
            boolean status = service.updatePolicy(policy);
            System.out.println(status ? HexaConstants.POLICY_UPDATED : HexaConstants.POLICY_UPDATE_FAILED);
        } catch (Exception e) {
            System.out.println(HexaConstants.INVALID_INPUT + e.getMessage());
            scanner.nextLine();
        }
    }

    private static void deletePolicy() {
        try {
            System.out.print(HexaConstants.ENTER_POLICY_ID_DELETE);
            int id = scanner.nextInt();
            boolean status = service.deletePolicy(id);
            System.out.println(status ? HexaConstants.POLICY_DELETED : HexaConstants.POLICY_DELETE_FAILED);
        } catch (DatabaseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(HexaConstants.INVALID_INPUT + e.getMessage());
            scanner.nextLine();
        }
    }

    private static void displayPolicy(Policy policy) {
        System.out.println(HexaConstants.POLICY_ID + ": " + policy.getPolicyId());
        System.out.println(HexaConstants.POLICY_NAME + ": " + policy.getPolicyName());
        System.out.println(HexaConstants.COVERAGE_AMOUNT + ": " + policy.getCoverageAmount());
        System.out.println(HexaConstants.START_DATE + ": " + policy.getStartDate());
        System.out.println(HexaConstants.END_DATE + ": " + policy.getEndDate());
        System.out.println(HexaConstants.SEPARATOR);
    }
}
