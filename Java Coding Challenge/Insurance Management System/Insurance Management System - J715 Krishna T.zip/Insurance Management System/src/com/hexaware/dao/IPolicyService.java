package com.hexaware.dao;

import java.util.Collection;

import com.hexaware.entity.Policy;
import com.hexaware.exception.DatabaseException;
import com.hexaware.exception.PolicyNotFoundException;

public interface IPolicyService {

    boolean createPolicy(Policy policy) throws DatabaseException;

    Policy getPolicy(int policyId) throws DatabaseException, PolicyNotFoundException;

    Collection<Policy> getAllPolicies() throws DatabaseException;

    boolean updatePolicy(Policy policy) throws DatabaseException;

    boolean deletePolicy(int policyId) throws DatabaseException;
}
