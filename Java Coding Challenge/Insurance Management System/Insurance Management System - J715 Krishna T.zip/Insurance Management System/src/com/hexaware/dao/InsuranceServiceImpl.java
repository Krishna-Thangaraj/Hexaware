package com.hexaware.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;

import com.hexaware.entity.Policy;
import com.hexaware.exception.DatabaseException;
import com.hexaware.exception.PolicyNotFoundException;
import com.hexaware.util.DBUtil;
import com.hexaware.util.HexaConstants;

public class InsuranceServiceImpl implements IPolicyService {

    @Override
    public boolean createPolicy(Policy policy) throws DatabaseException {
        try (Connection con = DBUtil.getDBConn();
             PreparedStatement ps = con.prepareStatement(HexaConstants.INSERT_POLICY)) {

            ps.setString(1, policy.getPolicyName());
            ps.setDouble(2, policy.getCoverageAmount());
            ps.setDate(3, java.sql.Date.valueOf(policy.getStartDate()));
            ps.setDate(4, java.sql.Date.valueOf(policy.getEndDate()));

            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            throw new DatabaseException(HexaConstants.DB_INSERT_ERROR + e.getMessage());
        }
    }

    @Override
    public Policy getPolicy(int policyId) throws DatabaseException, PolicyNotFoundException {
        try (Connection con = DBUtil.getDBConn();
             PreparedStatement ps = con.prepareStatement(HexaConstants.SELECT_POLICY_BY_ID)) {

            ps.setInt(1, policyId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getDouble("coverageAmount"),
                    rs.getDate("startDate").toLocalDate(),
                    rs.getDate("endDate").toLocalDate()
                );
            } else {
                throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
            }

        } catch (SQLException e) {
            throw new DatabaseException(HexaConstants.DB_FETCH_ERROR + e.getMessage());
        }
    }

    @Override
    public Collection<Policy> getAllPolicies() throws DatabaseException {
        Collection<Policy> policies = new ArrayList<>();
        try (Connection con = DBUtil.getDBConn();
             PreparedStatement ps = con.prepareStatement(HexaConstants.SELECT_ALL_POLICIES);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Policy policy = new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getDouble("coverageAmount"),
                   
                    rs.getDate("startDate").toLocalDate(),
                    rs.getDate("endDate").toLocalDate()
                );
                policies.add(policy);
            }
        } catch (SQLException e) {
            throw new DatabaseException(HexaConstants.DB_FETCH_ERROR + e.getMessage());
        }
        return policies;
    }

    @Override
    public boolean updatePolicy(Policy policy) throws DatabaseException {
        try (Connection con = DBUtil.getDBConn();
             PreparedStatement ps = con.prepareStatement(HexaConstants.UPDATE_POLICY)) {

            ps.setString(1, policy.getPolicyName());
            ps.setDouble(2, policy.getCoverageAmount());
            
            ps.setDate(3, java.sql.Date.valueOf(policy.getStartDate()));
            ps.setDate(4, java.sql.Date.valueOf(policy.getEndDate()));
            ps.setInt(5, policy.getPolicyId());

            int result = ps.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            throw new DatabaseException(HexaConstants.DB_UPDATE_ERROR + e.getMessage());
        }
    }

    @Override
    public boolean deletePolicy(int policyId) throws DatabaseException {
        try (Connection con = DBUtil.getDBConn();
             PreparedStatement ps = con.prepareStatement(HexaConstants.DELETE_POLICY)) {

            ps.setInt(1, policyId);
            int result = ps.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            throw new DatabaseException(HexaConstants.DB_DELETE_ERROR + e.getMessage());
        }
    }
}
