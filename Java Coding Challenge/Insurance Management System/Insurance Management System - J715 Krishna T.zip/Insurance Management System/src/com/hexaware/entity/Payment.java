package com.hexaware.entity;

import java.time.LocalDate;
import java.util.Objects;

import com.hexaware.util.HexaConstants;

public class Payment {
    private int paymentId;
    private LocalDate paymentDate;
    private double paymentAmount;
    private int clientId;

    public Payment(int paymentId, LocalDate paymentDate, double paymentAmount, int clientId) {
        this.paymentId = paymentId;
        this.paymentDate = paymentDate;
        this.paymentAmount = paymentAmount;
        this.clientId = clientId;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    @Override
    public String toString() {
        return HexaConstants.PAYMENT_ID + paymentId + ", "
             + HexaConstants.PAYMENT_DATE + paymentDate + ", "
             + HexaConstants.PAYMENT_AMOUNT + paymentAmount + ", "
             + HexaConstants.CLIENT_ID + clientId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Payment)) return false;
        Payment payment = (Payment) o;
        return paymentId == payment.paymentId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentId);
    }
}
