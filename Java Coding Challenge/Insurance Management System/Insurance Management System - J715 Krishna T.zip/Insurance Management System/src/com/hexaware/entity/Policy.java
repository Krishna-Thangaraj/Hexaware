package com.hexaware.entity;

import java.time.LocalDate;
import java.util.Objects;

import com.hexaware.util.HexaConstants;

public class Policy {
    private int policyId;
    private String policyName;
    private double coverageAmount;
    private double premium;
    private LocalDate startDate;
    private LocalDate endDate;

    public Policy(int policyId, String policyName, double coverageAmount, LocalDate startDate, LocalDate endDate) {
        this.policyId = policyId;
        this.policyName = policyName;
        this.coverageAmount = coverageAmount;
   
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public double getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return HexaConstants.POLICY_ID + policyId + ", "
             + HexaConstants.POLICY_NAME + policyName + ", "
             + HexaConstants.COVERAGE_AMOUNT + coverageAmount + ", "
             + HexaConstants.PREMIUM + premium + ", "
             + HexaConstants.START_DATE + startDate + ", "
             + HexaConstants.END_DATE + endDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Policy)) return false;
        Policy policy = (Policy) o;
        return policyId == policy.policyId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(policyId);
    }
}
