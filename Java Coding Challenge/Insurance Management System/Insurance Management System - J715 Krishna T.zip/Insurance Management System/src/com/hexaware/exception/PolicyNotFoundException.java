package com.hexaware.exception;

import com.hexaware.util.HexaConstants;

public class PolicyNotFoundException extends Exception {

    public PolicyNotFoundException() {
        super();
    }

    public PolicyNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public PolicyNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public PolicyNotFoundException(String message) {
        super(message);
    }

    public PolicyNotFoundException(Throwable cause) {
        super(cause);
    }

    @Override
    public String toString() {
        return HexaConstants.POLICY_NOT_FOUND;
    }
}
