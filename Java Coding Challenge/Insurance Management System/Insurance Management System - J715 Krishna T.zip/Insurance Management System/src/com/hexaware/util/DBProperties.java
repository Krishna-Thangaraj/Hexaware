package com.hexaware.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBProperties {
    private static Properties props = new Properties();

    static {
        try (FileInputStream fis = new FileInputStream(HexaConstants.DB_FILE_NAME)) {
            props.load(fis);
        } catch (IOException e) {
            System.err.println("Unable to load DB properties: " + e.getMessage());
        }
    }

    public static String getDriver() {
        return props.getProperty(HexaConstants.DB_DRIVER);
    }

    public static String getDbUrl() {
        return props.getProperty(HexaConstants.DB_URL);
    }

    public static String getUser() {
        return props.getProperty(HexaConstants.DB_USERNAME);
    }

    public static String getPassword() {
        return props.getProperty(HexaConstants.DB_PASSWORD);
    }
}
