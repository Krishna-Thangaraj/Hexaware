package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.InputStream;

public class DBUtil {

    private static String url;
    private static String username;
    private static String password;
    private static String driver;

    static {
        try {
            Properties props = new Properties();
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            InputStream in = loader.getResourceAsStream("insurance.properties");

            if (in == null) {
                throw new RuntimeException("insurance.properties file not found in classpath!");
            }

            props.load(in);

            driver = props.getProperty("driver");
            url = props.getProperty("url");
            username = props.getProperty("username");
            password = props.getProperty("password");

            Class.forName(driver);
        } catch (Exception e) {
            System.out.println("Unable to load DB properties: " + e.getMessage());
        }
    }

    public static Connection getDBConn() {
        try {
            return DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            System.out.println("Unable to establish DB connection: " + e.getMessage());
            return null;
        }
    }
}
