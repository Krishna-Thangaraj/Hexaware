package com.hexaware.util;

public class HexaConstants {
    public static final String DB_FILE_NAME = "insurance.properties";
    public static final String DB_DRIVER = "driver";
    public static final String DB_URL = "dburl";
    public static final String DB_USERNAME = "user";
    public static final String DB_PASSWORD = "password";

    public static final String CANNOT_OPEN_CONNECTION = "Unable to establish a database connection.";

    // Prompt messages
    public static final String PROMPT_POLICY_ID = "Enter Policy ID:";
    public static final String PROMPT_USER_ID = "Enter User ID:";
    public static final String PROMPT_CLAIM_ID = "Enter Claim ID:";
    public static final String PROMPT_PAYMENT_ID = "Enter Payment ID:";
    public static final String PROMPT_CLIENT_ID = "Enter Client ID:";

    // Status messages
    public static final String POLICY_ADDED = "Policy successfully added.";
    public static final String CLAIM_SUBMITTED = "Claim successfully submitted.";
    public static final String PAYMENT_PROCESSED = "Payment successfully processed.";
    public static final String CLIENT_REGISTERED = "Client successfully registered.";
    public static final String USER_REGISTERED = "User successfully registered.";

    public static final String RECORD_NOT_FOUND = "Record not found.";
    public static final String POLICY_NOT_FOUND = "Policy not found with the given policy number.";
    public static final String DATABASE_ERROR = "An error occurred while accessing the database.";

    // User
    public static final String USER_ID = "User ID: ";
    public static final String USERNAME = "Username: ";
    public static final String PASSWORD = "Password: ";
    public static final String ROLE = "Role: ";

    // Policy
    public static final String POLICY_ID = "Policy ID: ";
    public static final String POLICY_NAME = "Policy Name: ";
    public static final String COVERAGE_AMOUNT = "Coverage Amount: ";
    public static final String PREMIUM = "Premium: ";
    public static final String START_DATE = "Start Date: ";
    public static final String END_DATE = "End Date: ";

    // Client
    public static final String CLIENT_ID = "Client ID: ";
    public static final String CLIENT_NAME = "Client Name: ";
    public static final String CONTACT_INFO = "Contact Info: ";

    // Claim
    public static final String CLAIM_ID = "Claim ID: ";
    public static final String CLAIM_NUMBER = "Claim Number: ";
    public static final String DATE_FILED = "Date Filed: ";
    public static final String CLAIM_AMOUNT = "Claim Amount: ";
    public static final String STATUS = "Status: ";

    // Payment
    public static final String PAYMENT_ID = "Payment ID: ";
    public static final String PAYMENT_DATE = "Payment Date: ";
    public static final String PAYMENT_AMOUNT = "Payment Amount: ";
    
 
    // Database Error Messages
    public static final String DB_INSERT_ERROR = "Error while inserting policy: ";
    public static final String DB_FETCH_ERROR = "Error while fetching policy data: ";
    public static final String DB_UPDATE_ERROR = "Error while updating policy: ";
    public static final String DB_DELETE_ERROR = "Error while deleting policy: ";

    // SQL Queries - Policy Table
    public static final String INSERT_POLICY =
        "INSERT INTO Policy (policyName, coverageAmount,startDate, endDate) VALUES (?, ?, ?, ?)";

    public static final String SELECT_POLICY_BY_ID =
        "SELECT * FROM Policy WHERE policyId = ?";

    public static final String SELECT_ALL_POLICIES =
        "SELECT * FROM Policy";

    public static final String UPDATE_POLICY =
        "UPDATE Policy SET policyName=?, coverageAmount=?, startDate=?, endDate=? WHERE policyId=?";

    public static final String DELETE_POLICY =
        "DELETE FROM Policy WHERE policyId=?";
    
 // Input prompts
    public static final String ENTER_CHOICE = "Enter your choice: ";
    public static final String CONTINUE_PROMPT = "Do you want to continue? (y/n): ";
    public static final String ENTER_POLICY_NAME = "Enter Policy Name: ";
    public static final String ENTER_COVERAGE_AMOUNT = "Enter Coverage Amount: ";
    public static final String ENTER_PREMIUM = "Enter Premium: ";
    public static final String ENTER_START_DATE = "Enter Start Date (yyyy-MM-dd): ";
    public static final String ENTER_END_DATE = "Enter End Date (yyyy-MM-dd): ";
    public static final String ENTER_POLICY_ID = "Enter Policy ID: ";
    public static final String ENTER_POLICY_ID_UPDATE = "Enter Policy ID to Update: ";
    public static final String ENTER_POLICY_ID_DELETE = "Enter Policy ID to Delete: ";

    // Misc
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String SEPARATOR = "------------------------------------------";
    


    // Menu text
    public static final String MENU = """
        ========== Insurance Management Menu ==========
        1. Create New Policy
        2. View Policy by ID
        3. View All Policies
        4. Update Existing Policy
        5. Delete Policy
        ===============================================
        """;

    // Status Messages
    public static final String POLICY_CREATED = "Policy created successfully!";
    public static final String POLICY_CREATION_FAILED = "Failed to create policy.";
    public static final String POLICY_UPDATED = "Policy updated successfully!";
    public static final String POLICY_UPDATE_FAILED = "Failed to update policy.";
    public static final String POLICY_DELETED = "Policy deleted successfully!";
    public static final String POLICY_DELETE_FAILED = "Failed to delete policy.";
    public static final String NO_POLICIES_FOUND = "No policies found in the system.";
    public static final String INVALID_CHOICE = "Invalid menu option selected.";
    public static final String INVALID_INPUT = "Invalid input: ";

  

}
