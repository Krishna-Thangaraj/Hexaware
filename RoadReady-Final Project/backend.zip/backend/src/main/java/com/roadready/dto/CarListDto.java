package com.roadready.dto;

import lombok.Data;

import java.util.List;

@Data
public class CarListDto {

    private List<CarDto> carDtoList;

}
