package com.roadready.dto;

import lombok.Data;

@Data
public class SearchDto {

    private String brand;
    private String type;
    private String transmission;
    private String color;

}
