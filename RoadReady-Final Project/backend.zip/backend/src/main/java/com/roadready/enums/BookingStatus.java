package com.roadready.enums;

public enum BookingStatus {

    PENDING,
    APPROVED,
    REJECTED

}
