package com.roadready.enums;

public enum UserRole {

    ADMIN,
    CUSTOMER

}
