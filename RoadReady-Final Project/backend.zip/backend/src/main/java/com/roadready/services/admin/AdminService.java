package com.roadready.services.admin;

import com.roadready.dto.BookDto;
import com.roadready.dto.CarDto;
import com.roadready.dto.CarListDto;
import com.roadready.dto.SearchDto;

import java.io.IOException;
import java.util.List;

public interface AdminService {

    boolean addCar(CarDto carDto) throws IOException;

    List<CarDto> getAllCars();

    void deleteCar(Long id);

    CarDto getCarById(Long id);

    boolean updateCar(Long carId, CarDto carDto) throws IOException;

    List<BookDto> getBookings();

    boolean changeBookingStatus(Long bookingId, String status);

    CarListDto searchCar(SearchDto searchDto);

}
