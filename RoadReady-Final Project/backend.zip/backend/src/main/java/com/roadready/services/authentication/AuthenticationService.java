package com.roadready.services.authentication;

import com.roadready.dto.RegisterRequest;
import com.roadready.dto.UserDto;

public interface AuthenticationService {

    UserDto createCustomer(RegisterRequest registerRequest);
    boolean hasCustomerWithEmail(String email);

}
