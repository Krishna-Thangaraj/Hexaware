package com.roadready.services.customer;

import com.roadready.dto.BookDto;
import com.roadready.dto.CarDto;
import com.roadready.dto.CarListDto;
import com.roadready.dto.SearchDto;

import java.util.List;

public interface CustomerService {

    List<CarDto> getAllCars();

    boolean bookCar(BookDto bookDto);

    CarDto getCarById(Long carId);

    List<BookDto> getBookingByUserId(Long userId);

    CarListDto searchCar(SearchDto searchDto);

}
