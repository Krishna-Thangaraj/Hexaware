package com.roadready.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.roadready.model.Car;
import com.roadready.service.CarService;

@RestController
@RequestMapping("/api/cars")
public class CarController {

    @Autowired
    private CarService carService;

    @GetMapping
    public ResponseEntity<?> getAllCars() {
        List<Car> cars = carService.getAllCars();
        return ResponseEntity.ok(Map.of(
            "message", "Fetched all cars",
            "data", cars
        ));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> addCar(@RequestBody Car car) {
        Car savedCar = carService.addCar(car);
        return ResponseEntity.ok(Map.of(
            "message", "Car successfully inserted",
            "car", savedCar
        ));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateCar(@PathVariable Long id, @RequestBody Car car) {
        car.setId(id);
        Car updatedCar = carService.updateCar(car);
        return ResponseEntity.ok(Map.of(
            "message", "Car successfully updated",
            "car", updatedCar
        ));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteCar(@PathVariable Long id) {
        carService.deleteCar(id);
        return ResponseEntity.ok(Map.of(
            "message", "Car successfully deleted",
            "carId", id
        ));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getCarById(@PathVariable Long id) {
        Car car = carService.getCarById(id);
        if (car != null) {
            return ResponseEntity.ok(Map.of(
                "message", "Car found",
                "car", car
            ));
        } else {
            return ResponseEntity.status(404).body(Map.of(
                "error", "Car not found",
                "carId", id
            ));
        }
    }
}
