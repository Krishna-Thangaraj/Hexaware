package com.roadready.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.roadready.model.Payment;
import com.roadready.service.PaymentService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {
    @Autowired private PaymentService paymentService;

    @PostMapping("/pay")
    public Payment makePayment(@RequestParam Long bookingId, @RequestBody Payment payment) {
        return paymentService.makePayment(bookingId, payment);
    }
}
