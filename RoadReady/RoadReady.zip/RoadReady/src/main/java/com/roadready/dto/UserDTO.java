package com.roadready.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

public class UserDTO {

    @Schema(example = "Krish", description = "User's first name")
    @JsonProperty("firstName")
    private String firstName;

    @Schema(example = "Dev", description = "User's last name")
    @JsonProperty("lastName")
    private String lastName;

    @Schema(example = "krish@example.com", description = "User's email address")
    @JsonProperty("email")
    private String email;

    @Schema(example = "secret123", description = "Plain password")
    @JsonProperty("rawPassword")
    private String rawPassword;

    @Schema(example = "9876543210", description = "User's phone number")
    @JsonProperty("phone")
    private String phone;

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRawPassword() { return rawPassword; }
    public void setRawPassword(String rawPassword) { this.rawPassword = rawPassword; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public static void main(String[] args) {
        UserDTO dto = new UserDTO();
        dto.setRawPassword("test123");
        System.out.println(dto.getRawPassword());
    }
}
