package com.roadready.service;

import com.roadready.dto.*;

public interface AuthService {
    String register(UserDTO userDTO);
    AuthResponse login(String email, String password);
}
