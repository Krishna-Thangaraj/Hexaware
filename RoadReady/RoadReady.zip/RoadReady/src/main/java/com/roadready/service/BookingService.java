package com.roadready.service;

import java.util.List;

import com.roadready.model.Booking;

public interface BookingService {
    Booking reserveCar(Long userId, Long carId, Booking booking);
    List<Booking> viewBookings(Long userId);
    void cancelBooking(Long bookingId);
    void deleteById(Long id);
    Booking findById(Long id);
}

