package com.roadready.service;

import java.util.List;

import com.roadready.model.Car;

public interface CarService {
    List<Car> getAllCars();
    Car addCar(Car car);
    Car updateCar(Car car);
    void deleteCar(Long id);
    Car getCarById(Long id);
}
