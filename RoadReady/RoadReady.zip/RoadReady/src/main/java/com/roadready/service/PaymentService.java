package com.roadready.service;

import com.roadready.model.Payment;

public interface PaymentService {
    Payment makePayment(Long bookingId, Payment payment);
}
