package com.roadready.service;

import java.util.List;
import com.roadready.model.Review;

public interface ReviewService {
    Review addReview(Long userId, Long carId, Review review);
    List<Review> getReviewsForCar(Long carId);
    Review updateReview(Review review);
    void deleteReview(Long id);
    Review getById(Long id);
}
