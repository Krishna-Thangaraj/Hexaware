package com.roadready.service.impl;

import com.roadready.dto.AuthResponse;
import com.roadready.dto.UserDTO;
import com.roadready.model.Role;
import com.roadready.model.User;
import com.roadready.repository.RoleRepository;
import com.roadready.repository.UserRepository;
import com.roadready.security.JwtUtil;
import com.roadready.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public String register(UserDTO dto) {
        System.out.println("RAW PASSWORD RECEIVED: " + dto.getRawPassword()); // 🔍 Debug log

        if (userRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setPassword(passwordEncoder.encode(dto.getRawPassword()));

        Role userRole = roleRepository.findByName("USER").orElseGet(() -> {
            Role newRole = new Role();
            newRole.setName("USER");
            return roleRepository.save(newRole);
        });

        user.setRoles(new HashSet<>()); // Ensure roles set is not null
        user.getRoles().add(userRole);
        userRepository.save(user);

        return "User registered successfully";
    }

    @Override
    public AuthResponse login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user);
        String role = user.getRoles().stream()
                .findFirst()
                .map(Role::getName)
                .orElse("USER");

        return new AuthResponse(token, role);
    }
}
