package com.roadready.service.impl;

import com.roadready.model.Booking;
import com.roadready.model.Car;
import com.roadready.model.User;
import com.roadready.repository.BookingRepository;
import com.roadready.repository.CarRepository;
import com.roadready.repository.UserRepository;
import com.roadready.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired private BookingRepository bookingRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private CarRepository carRepository;

    @Override
    public Booking reserveCar(Long userId, Long carId, Booking booking) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new RuntimeException("Car not found"));

        booking.setUser(user);
        booking.setCar(car);
        booking.setStatus("Reserved");
        return bookingRepository.save(booking);
    }

    @Override
    public List<Booking> viewBookings(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    @Override
    public void cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        booking.setStatus("Cancelled");
        bookingRepository.save(booking);
    }

    @Override
    public void deleteById(Long id) {
        bookingRepository.deleteById(id);
    }

    @Override
    public Booking findById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }
}
