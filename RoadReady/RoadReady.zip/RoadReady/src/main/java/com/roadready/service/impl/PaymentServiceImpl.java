package com.roadready.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roadready.model.Booking;
import com.roadready.model.Payment;
import com.roadready.repository.BookingRepository;
import com.roadready.repository.PaymentRepository;
import com.roadready.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
    @Autowired private PaymentRepository paymentRepository;
    @Autowired private BookingRepository bookingRepository;

    public Payment makePayment1(Long bookingId, Payment payment) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow(() -> new RuntimeException("Booking not found"));
        payment.setBooking(booking);
        payment.setStatus("Paid");
        return paymentRepository.save(payment);
    }

	@Override
	public Payment makePayment(Long bookingId, Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}
}
