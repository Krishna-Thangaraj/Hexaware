package com.roadready.service.impl;

import com.roadready.model.Car;
import com.roadready.model.Review;
import com.roadready.model.User;
import com.roadready.repository.CarRepository;
import com.roadready.repository.ReviewRepository;
import com.roadready.repository.UserRepository;
import com.roadready.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarRepository carRepository;

    @Override
    public Review addReview(Long userId, Long carId, Review review) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new RuntimeException("Car not found"));

        review.setUser(user);
        review.setCar(car);
        return reviewRepository.save(review);
    }

    @Override
    public List<Review> getReviewsForCar(Long carId) {
        return reviewRepository.findByCarId(carId);
    }

    @Override
    public Review updateReview(Review review) {
        Review existing = reviewRepository.findById(review.getId())
                .orElseThrow(() -> new RuntimeException("Review not found"));
        existing.setComment(review.getComment());
        existing.setRating(review.getRating());
        return reviewRepository.save(existing);
    }

    @Override
    public void deleteReview(Long id) {
        reviewRepository.deleteById(id);
    }

    @Override
    public Review getById(Long id) {
        return reviewRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Review not found"));
    }
}
